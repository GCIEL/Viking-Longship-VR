# GCIEL Viking Longship Virtual Reality Project: Design Document

[Design Document](https://docs.google.com/document/d/1ahpt8RlQ58NMocUhqjjqLX6mTlBZTGIRhK_KIxh_9O8/edit?usp=sharing)

[Video Description](https://youtu.be/51_IwFGMHgY)
